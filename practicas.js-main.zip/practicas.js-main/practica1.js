var x= 'Bienvenida "Yessenia" :)';
var y= 'We\'re the champions';

console.log(x);
console.log(y);

var a = 5;
var b = 10;
var c = 15;

console.log(a + b);
console.log(a - b);
console.log(a * b);
console.log(a / b);
console.log(a + b * c);
console.log((a + b) * c);
console.log(b/a * c)
console.log(b/(a*c));
console.log(a -b + c);
console.log(a - (b + c));

console.log(3 + b) * c / a * 2;
console.log((a + b * c) / 5) * 2;
console.log (b / a + 2* c);
console.log(a + b + c /c)  * a;
console.log((3 * a) / c) + a + b +c;
console.log (a - (b + c) * a / 1);
